<?php

namespace App\Models;

class User{

}