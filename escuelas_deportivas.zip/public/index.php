<?php
ini_set('date.timezone', 'America/lima');
require __DIR__ . '/../bootstrap/app.php';

$app->run();